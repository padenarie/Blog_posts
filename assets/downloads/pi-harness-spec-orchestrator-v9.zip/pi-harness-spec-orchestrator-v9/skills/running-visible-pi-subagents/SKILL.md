---
name: running-visible-pi-subagents
description: Use when an agent must launch, monitor, steer, review, or clean up a persistent interactive PI subagent that a macOS user can watch in Terminal.
---

# Running Visible PI Subagents

## Overview

PI work is a persistent, interactive session controlled by the orchestrator. The user sees the PI TUI in macOS Terminal; they never have to create tmux sessions, attach windows, paste prompts, or relay output.

Use `tracing-agent-orchestration` for repository-local task handoffs and results.

## Model selection

1. Require the user to select an exact model before launching PI.
2. Verify `pi` runs. Match the user's choice to this registry. If absent or a registry command fails, run `pi --list-models`; never substitute a similar model.
3. If unavailable, stop and request another user-selected model.

| User-facing model | Provider | Exact model argument |
|---|---|---|
| oMLX Qwen 3.8 27b | `omlx` | `Qwen3.8-27B-oQ4` |
| Home llama.cpp Qwen3.8 UD Q4 K XL | `home-llama-cpp` | `<path-to-your-model.gguf>` |
| LM Studio Qwen 3.8 27b splash | `lmstudio` | `qwen3.8-27b-splash` |
| LM Studio Qwen 3.6 35b A3B splash | `lmstudio` | `qwen3.6-35b-a3b-splash` |

Launch only normal interactive PI. Never use `-p`, `--print`, `--mode text|json|rpc`, `--no-session`, or `--no-tools` for implementation or review.

## Launch contract

Use a deterministic task session name such as `pi-task-01-implementation`. Check an existing name first with `tmux has-session -t "<session>" 2>/dev/null`; inspect it before reuse or termination.

| Work shape | tmux topology | Visible Terminal topology |
|---|---|---|
| Sequential | persistent `pi-orchestrator` session; one named window per task | one reused Terminal attached to `pi-orchestrator` |
| Parallel | one tmux session per task | one dedicated Terminal per concurrent session |

Sequential bootstrap:

```bash
tmux has-session -t pi-orchestrator 2>/dev/null || tmux new-session -d -s pi-orchestrator -n control
tmux set-option -t pi-orchestrator mouse on
tmux set-option -t pi-orchestrator history-limit 100000
osascript -e 'tell application "Terminal" to do script "tmux attach -t pi-orchestrator"'
tmux new-window -t pi-orchestrator -n "$SESSION" -c "$REPO" "pi --provider <provider> --model <exact-model-id> --name '$SESSION'"
tmux select-window -t "pi-orchestrator:$SESSION"
```

Only open the sequential Terminal once. For parallel tasks, create each isolated session with `tmux new-session -d -s "$SESSION" -c "$REPO" "pi --provider <provider> --model <exact-model-id> --name '$SESSION'"`, then attach a dedicated Terminal with AppleScript. Do not put the PI prompt in AppleScript or run parallel tasks in one shared PI session/window. Parallel tasks must not edit shared files or depend on mutable output.

For reviews, start a fresh session with `--tools read,grep,find,ls`; implementation sessions keep normal PI tools.

## Handoff, monitoring, and cleanup

Write substantial task/steering text to the repository trace first, then send only `Read @<trace-file> and execute it now.` using `tmux send-keys`. Keep the same PI session for follow-ups.

Observe the TUI with `tmux capture-pane -t "<session>" -p -S -400` and inspect the shared working tree at meaningful milestones. Report actual in-progress changes without editing or duplicating PI's work.

Task completion requires: PI has ended its turn, expected output exists, the orchestrator inspected it, required validation has run or its limitation is recorded, and trace results are updated.

For sequential work, clean up only the task window, then return to `control`:

```bash
tmux kill-window -t "pi-orchestrator:$SESSION"
tmux select-window -t pi-orchestrator:control
```

Keep `pi-orchestrator` and its Terminal for later sequential work. For a completed parallel task, kill only its dedicated session; close its Terminal only when it can be safely identified. Never terminate unrelated user tmux sessions or Terminal windows.

## Common mistakes

- Opening a new Terminal for each sequential task instead of reusing the visible workspace.
- Using separate windows within one session for parallel PI tasks; users cannot watch each independently.
- Sending long prompts through `tmux send-keys` instead of a trace file.
- Treating a running PI process as task completion without inspecting output and validation.
