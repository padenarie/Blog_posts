---
name: tracing-agent-orchestration
description: Use when orchestrating one or more subagents and their intermediate prompts, progress, steering, reviews, outcomes, or pause-and-resume recovery must be preserved in the repository.
---

# Tracing Agent Orchestration

## Overview

Trace decisions and durable milestones, not transcripts. A fresh orchestrator must be able to resume from repository-local state without relying on chat history, while traces never capture secrets, credentials, raw token streams, large artifacts, or copied source files.

## Trace contract

Store every workflow below `.agent-traces/`. Use the stable run id `YYYYMMDD-HHMM-<short-workflow-slug>`.

```text
.agent-traces/
  registry.md
  active-run
  <run-id>/
    run.md
    state.md
    resume.md
    events.md
    task-01-<slug>/
      00-task.md
      10-progress.md
      steering/001-<slug>.md
      20-result.md
      review/00-review-task.md
      review/10-findings.md
```

`active-run` contains exactly one run id while work is active or paused. `registry.md` is append/update only; do not erase earlier run history automatically.

| File | Required content |
|---|---|
| `run.md` | workflow/spec name, repository, orchestrator, approved tasks/models/sessions, status, user decisions, task-trace links |
| `state.md` | current phase/objective, run status, every task status, sessions, repository progress, validation, blockers, exact next action |
| `resume.md` | the smallest recovery brief and links to only necessary task traces |
| `events.md` | concise ordered lifecycle events, including dispatch, milestone, steering, completion, failure, pause, and resume |
| `00-task.md` | exact handoff: objective, specification, boundaries, criteria, repository, validation, Git/tool limits, inspect-first and result-oriented instructions |
| `10-progress.md` | durable observed milestone—not raw TUI output |
| `20-result.md` | changed files, validation, concerns, and completion result |

Write substantive prompts, steering, and review handoffs to these files before sending a short in-session reference. Never use `/tmp` for traceable orchestration material.

## Status and reconciliation

Use only these run statuses: `PLANNING`, `WAITING_FOR_USER`, `RUNNING`, `PAUSING`, `PAUSED`, `RESUMING`, `COMPLETED`, `FAILED`, `ABORTED`.

Use only these task statuses: `NOT_STARTED`, `RUNNING`, `WAITING`, `STALLED`, `BLOCKED`, `COMPLETED_UNPROCESSED`, `COMPLETED`, `FAILED_UNPROCESSED`, `FAILED`, `STOPPED`.

After dispatch, steering, an observed completion/failure, a parallel start, before long local work, before a multi-worker progress update, and before pause/stop, reconcile all active or unprocessed tasks:

1. Read `state.md`.
2. Inspect each `RUNNING`, `WAITING`, `STALLED`, or `BLOCKED` worker and relevant repository progress.
3. Update state. Mark finished work `COMPLETED_UNPROCESSED` or `FAILED_UNPROCESSED`; append its event.
4. Inspect and record every unprocessed result before changing it to `COMPLETED` or `FAILED`.
5. Identify approved, independent ready work and update all run/checkpoint files.

Never assume another active worker stayed unchanged while attention was elsewhere.

## Milestones, pause, and resume

Checkpoint when work/review starts or ends, a meaningful milestone occurs, steering happens, a stall/blocker is found, scope/model changes, a user pauses, or before ending a session. Record concise facts: changed paths, validation in progress, scope change, and steering needed.

On pause: stop dispatch, set `PAUSING`, reconcile all workers, capture their meaningful state, update run/state/resume/registry, stop only active turns safely without discarding edits, mark workers `STOPPED`, then set `PAUSED`.

On resume: read `active-run`, `state.md`, `resume.md`, and linked necessary traces; compare with the actual working tree. If they disagree materially, surface the discrepancy before changes or dispatch. Otherwise set `RESUMING`, execute the recorded next action, then set `RUNNING`.

## Common mistakes

- Marking completed work final before inspecting its result.
- Recording raw terminal output instead of a concise milestone.
- Allowing concurrent workers to disappear from the registry while another task is reviewed.
- Storing tokens, credentials, environment secrets, or generated artifacts in traces.
- Recreating all sessions on resume rather than only unfinished work.
