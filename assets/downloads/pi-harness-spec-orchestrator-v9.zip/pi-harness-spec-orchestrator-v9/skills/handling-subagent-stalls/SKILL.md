---
name: handling-subagent-stalls
description: Use when an implementation subagent repeatedly plans, inspects, or restates work without concrete repository progress after its approved task is sufficiently specified.
---

# Handling Subagent Stalls

## Overview

Repeated planning is a diagnostic signal, not automatically a failure or permission to terminate work. Confirm the evidence, preserve user control, and keep the same session whenever the user chooses a recoverable action.

## Diagnose before acting

Flag a potential stall only when the approved task is actionable and the agent repeatedly restates the plan, rereads the same files without a new finding, promises an edit without making it, or debates settled options.

Inspect the agent output and shared working tree first. A task that is reasoning, inspecting new information, or validating an existing material change is not stalled. Classify the observed state precisely: `STALLED`, `BLOCKED`, scope violation, process/model failure, or user-approved abort.

## User decision gate

Do not send Escape, Ctrl-C, kill the session/window, or switch models merely because the agent appears over-planned. Notify the user and use the approved question mechanism to offer:

| Choice | Action |
|---|---|
| Steer and continue (recommended) | Write and send a focused next-action instruction in the same session. |
| Let it continue | Leave the session untouched and keep monitoring. |
| Interrupt and redirect | Record the redirect, send Escape, inspect, then issue the revised instruction in the same session. |
| Abort this subagent | Terminate through the normal lifecycle after recording the user-approved decision. |
| Switch model | Stop only after the user selects the replacement and passes normal model selection. |

Recommend **Steer and continue** unless there is a hard failure, unsafe action, scope violation, or unrecoverable process state.

## Steering recipe

Record a substantial instruction in the task's trace before delivery. Its required shape is:

```text
Stop planning. The task is sufficiently specified. Perform the next smallest in-scope repository edit now, then run the most relevant focused validation. If you cannot proceed, report the exact blocker instead of continuing to plan.
```

After steering, reconcile every active worker and inspect actual repository progress. Do not label the agent failed merely because it has not edited yet.

## Invocation failure

Treat the task as unusable only when PI fails to launch, the selected provider/model fails, the tmux session exits unexpectedly, the model produces no useful result after the user-approved recovery path, repeatedly violates scope, or cannot complete through the selected configuration. Report the exact provider, model, session, and observed failure. Ask the user whether to retry it, choose another configured PI model, explicitly authorize the orchestrator to take over, or pause; follow only that choice.

## Common mistakes

- Killing a session on a hunch before checking its pane and working tree.
- Calling a blocked task a model failure without identifying the missing input or authority.
- Replacing the model without a user selection.
- Treating progress from an in-flight partial edit as a defect.
