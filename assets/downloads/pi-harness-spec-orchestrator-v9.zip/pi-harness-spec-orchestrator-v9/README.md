# Pi Harness Spec Orchestrator · public bundle

This bundle contains version 9 of Pierre-Antoine Denarié's VS Code Copilot custom agent and the three skills it requires. It accompanies the local AI experiment article.

## Included

```text
agents/pi-harness-spec-orchestrator.agent.md
skills/running-visible-pi-subagents/SKILL.md
skills/tracing-agent-orchestration/SKILL.md
skills/handling-subagent-stalls/SKILL.md
LICENSE
```

The agent handles discovery, specification, task breakdown, model selection, PI implementation tasks, task reviews, and final user approval. The skills provide visible PI sessions, repository-local traces, and a recovery path for stalled subagents.

## Requirements

- VS Code Copilot Chat with support for custom agents and agent skills.
- The PI CLI, configured with at least one usable model (`pi --list-models`).
- macOS Terminal, `tmux`, and `osascript` for the supplied visible-session workflow. Adapt the launch commands in `running-visible-pi-subagents` for another operating system or terminal.

## Install in a repository

1. Copy `agents/pi-harness-spec-orchestrator.agent.md` to `.github/agents/` in your repository.
2. Copy the three `skills/<name>/` folders to `.github/skills/` in the same repository.
3. Edit the model registry in `skills/running-visible-pi-subagents/SKILL.md` to match the provider and exact model IDs available in your PI setup. Replace `<path-to-your-model.gguf>` with your own path or remove that row. The listed models describe the author's setup; they are examples, not defaults guaranteed to work elsewhere.
4. Select **Pi Harness Spec Orchestrator** in Copilot Chat. Describe the work, review its specification and task breakdown, and choose the implementation model when prompted.

The agent intentionally asks for approval at its workflow gates and forbids Git write operations. Its prompts refer to `vscode_askQuestions`; adapt that question-tool name if your VS Code environment exposes a different one.

## Public-copy change

The four Markdown files are copied from the author's September 2026 source files. The only change within them is replacing one absolute model path in the model registry with `<path-to-your-model.gguf>`. No model credentials, trace records, repository data, or session logs are included.

Distributed under the Apache License 2.0 terms in `LICENSE`.
